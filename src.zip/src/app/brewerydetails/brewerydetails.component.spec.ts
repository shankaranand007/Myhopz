import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrewerydetailsComponent } from './brewerydetails.component';

describe('BrewerydetailsComponent', () => {
  let component: BrewerydetailsComponent;
  let fixture: ComponentFixture<BrewerydetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrewerydetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrewerydetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
