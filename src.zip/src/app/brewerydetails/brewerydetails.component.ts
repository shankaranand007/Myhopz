import { Component, OnInit, ViewChild,ChangeDetectorRef } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import 'rxjs/add/operator/toPromise';
import { Http, Headers, Response ,HttpModule} from '@angular/http';
import {ModalModule} from "ng2-modal";
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { Ng2MapModule,DirectionsRenderer} from 'ng2-map';
import { current } from '../service/current';
import { review } from '../service/review';
@Component({
  selector: 'app-brewerydetails',
  templateUrl: './brewerydetails.component.html',
  styleUrls: ['./brewerydetails.component.css']
})

export class BrewerydetailsComponent implements OnInit {
  rating: any;
  formated_address: any;
  img: any;
  spinnar: boolean;
  shop_id: any;
  logo_disp: boolean;
  lo: any;
  logo: any;
  current_state: any;
  current_city: any;
  or: string;
  ad: string;
 
  @ViewChild(DirectionsRenderer) directionsRendererDirective: DirectionsRenderer;
  lnggg: any;
  lattt: any;
  public data:any;
  starsCount:number = 3.5;
  website="bigbossbrewing.com";
  label: any;
  phone="+1 919-834-0045";
  zipcode: any;
  storetime="3:00 pm to 12:00 am";
  src: any;
  city: any;
  state: any;
  address: any;
  name: any;
  userId: any;
  float =3;
  zoom=10;
  public reviewdata=[];
  direction: any={};
  constructor(private command:review,private current:current,private activatedRoute: ActivatedRoute, private router: Router,private http:Http,private cdr: ChangeDetectorRef){}

  ngOnInit() {
    this.spinnar =true;
    this.logo_disp =false;
    this.current.local();
    this.activatedRoute.params.subscribe((params: Params) => {
      this.name = params['cmp_name'];
      this.address = params['address'];
      this.city = params['city'];
      this.lo = params['logo'];
      this.shop_id = params['shop_id'];
      console.log("logo"+this.lo);
      if(this.lo==""){this.logo="./assets/images/dl.png";}else{this.logo_disp=true;this.logo=this.lo;}
      this.state = params['state'];
      this.src = params['img'];
      this.storetime = params['storetime'];
      this.zipcode = params['zipcode'];
      this.phone = params['phone'];
      this.formated_address = params['formated_address'];
      this.label = params['label'];
      this.rating = params['rating'];
      this.website = params['website'];
      this.lattt = params['lattt'];
      this.lnggg =params['lnggg'];
     
      // alert(this.lattt+'//'+this.lnggg);
   });
   this.review();
   this.getImg();
   this.directionsRendererDirective['initialized$'].subscribe( directionsRenderer => {
    this.directionsRenderer = directionsRenderer;
  });
  var currentvalue = JSON.parse(localStorage.getItem('currentvalue'));
  console.log(currentvalue);
  (currentvalue.state==null)? this.current_state = "nc": this.current_state = currentvalue.state;
  (currentvalue.city==null)?this.current_city = "charlotte": this.current_city = currentvalue.city;
   
  this.ad =this.address,this.city,this.state; 
  this.or = "charlotte,nc"; 
   
  // this.ad = "coimbathore,chennai,india"; 
  // this.or = this.current_city+","+this.current_state; 
   
  this.direction.origin=this.or;
  this.direction.destination=this.ad;
  this.direction.travelMode='DRIVING';


  }
  review(){
    this.command.getReview(this.shop_id)
    .subscribe(
      data=>{
        console.log(data.result)
        this.reviewdata = data.result;
        this.spinnar =false;
      }
    );
  }
  getImg(){
    this.command.getImgg(this.shop_id)
    .subscribe(
      data=>{
        console.log(data.result);
        this.img = data.result;
      }
    );
  }
  ne(){
    var no="+1 919-916-5961";
    // var y = no.replace(/\s[&-\/\\#,()$~%.'":*?<>{}]/g,'');
    var y = no.replace(/[^0-9a-zA-Z+]/g,'');
    alert(y);
  }
  directionsRenderer: google.maps.DirectionsRenderer;
  directionsResult: google.maps.DirectionsResult;

  next(){
    
    this.router.navigate(['/login']);
  }

  onMapReady(map) {
    // alert("map ready")
    
    var directionsDisplay = new google.maps.DirectionsRenderer(); 
    directionsDisplay.addListener('directions_changed', function() {
      console.log(directionsDisplay.getDirections());
    });
    console.log('map', map);
    console.log('markers', map.markers);  
  }
  // computeTotalDistance(data){
  //   alert(data);
  // }
  directionsChanged() {
    this.directionsResult = this.directionsRenderer.getDirections();
    this.cdr.detectChanges();
    
  }

  showDirection() {
    this.directionsRendererDirective['showDirections'](this.direction);
  }
}
