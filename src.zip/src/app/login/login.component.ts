import { Component, forwardRef, Attribute,OnChanges, SimpleChanges,Input, OnInit } from '@angular/core';
import { FormsModule,ReactiveFormsModule,NG_VALIDATORS,Validator,Validators,AbstractControl,ValidatorFn, NgForm } from '@angular/forms';
import { signup } from '../service/signup';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { current } from '../service/current';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  admin_id: any;
  login_msg: boolean;
  msg: any;
  
model:any={}; 
  constructor(private current:current,private signup:signup,private router:Router) { }

  ngOnInit() {
    this.current.local();
  }
onLogin(){
  this.signup.login(this.model)
   .subscribe(
    data => { this.msg = data.msg;this.admin_id = data.result[0].merchant_id; console.log(this.admin_id)},
    err => console.log(err),
    
    () => {
    if(this.msg==0)
    {
    console.log("login fail");
    this.login_msg=true;
    setTimeout(()=>{ this.login_msg = false; },2000);
    }else
    {
      localStorage.setItem('admin', this.admin_id);
      // localStorage.setItem('verify',JSON.stringify({verify_id:1}));
      console.log("okey");this.router.navigate( ['/VerifybreweryComponent']);
    }});


}
}
