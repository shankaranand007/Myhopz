import { Component, OnInit,OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { verify } from '../service/verify';
@Component({
  selector: 'app-verifybrewary2',
  templateUrl: './verifybrewary2.component.html',
  styleUrls: ['./verifybrewary2.component.css']
})
export class Verifybrewary2Component implements OnInit {
  intt: any;
  otp: any;
  img: any;
  zipcode: any;
  country: any;
  state: any;
  city: any;
  address: any;
  cmp_name: any;
public mobile;
  constructor(private router:Router,private verifyy:verify) {
    this.intt =setInterval(()=> {
      this.inter(); },3000); 
    }
   
  ngOnInit() {
    // var currentuser = JSON.parse(localStorage.getItem('currentUser'));
    // this.mobile = currentuser.mob;
    this.otp= Math.floor(Math.random() * 90000) + 10000;
    var details = JSON.parse(localStorage.getItem('details'));
    if(details==null){
      this.cmp_name = "";
      this.address = "";
      this.city= "";
      this.state= "";
      this.country = "";
      this.zipcode =  "";
      this.img =  "";
      this.mobile =  "";
    }else{
     this.cmp_name = details.cmp_name;
     this.address = details.address;
     this.city= details.city;
     this.state=details.state;
     this.country = details.country;
     this.zipcode = details.zipcode;
     this.img = details.img;
     this.mobile = "9790054083";
     //this.mobile = details.phone;
    }

    if(details.phone==null||details.phone==undefined){console.log("phone number is empty")}else{this.verifyyy()}
    
  }
  ngOnDestroy() {
    if (this.intt) {
      clearInterval(this.intt);
    }
  }
  mobilee(){
    this.verifyy.ph(this.mobile,this.otp)
    .subscribe(
      data=>{console.log(data)}
    )
  }
  verifyyy(){
    this.verifyy.verify1(this.mobile,this.otp)
    .subscribe(
      data=>{
        console.log(data);
      }
    )
    this.mobilee();
  }
  // verify3(){
  //     this.router.navigate(["/Verifybrewary3Component"]);
  //     localStorage.setItem('v2','ss');
  // }

  inter(){
    this.verifyy.intervel(this.mobile,this.otp)
    .subscribe(
      data=>{console.log(data.result[0].OTP_ver_status);
        if(data.result[0].OTP_ver_status=='1'){ 
          this.router.navigate(["/Verifybrewary3Component"]);
        localStorage.setItem('v2','ss');
        //clearInterval(this.intt);
      }else if(data.error_code==1){alert("phone number not match")}else{}
      
      }
    )
  }
 
}
