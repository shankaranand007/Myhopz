import { Component, OnInit } from '@angular/core';
import { account_info } from '../service/account_info';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import {FormArray,FormControl, FormGroup,FormBuilder,FormsModule,ReactiveFormsModule,NG_VALIDATORS,Validator,Validators,AbstractControl,ValidatorFn, NgForm } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { print } from 'util';
@Component({
  selector: 'app-account-information',
  templateUrl: './account-information.component.html',
  styleUrls: ['./account-information.component.css']
})
export class AccountInformationComponent implements OnInit {
  ad: any;
  tax_method: any;
  city5: any;
  ac_routing: string;
  ac_num: string;
  referance_idd: any;
  referance_id: any;
  ss: void;
  payy_method: string;
  att: boolean;
  at: boolean;
  pay_method: any;
  bankname: any;
  account_type: any;
  account_holder: any;
  account_number: any;
  payto: any;
  routing: any;
  active2: boolean;
  active: boolean;
  active1: boolean;
  tabpayy: boolean=true;
  tabinfoo: boolean=true;
  tabbilll: boolean=true;
  tax_number: any;
    taxx_id: any;
    zipe: any;
    tax_id: any;
    tax_state: any;
    tax_zip: any;
    tax_city: any;
    tax_country: any;
    tax_address2: any;
    tax_address1: any;
    fedaralclass: any;
    bussinessname: any;
    taxname: any;
    b_id: any;
    zip: any;
    state: any;
    city= "";
    country: any;
    address2="";
    address1="";
    beneficiary_name: any;
    t2: any;
    taboverview:boolean=true;
    tabbill;
    tabpay;
    tabinfo;
    msg2: any;
    t1: any;
    msg1: any;
    t: any;
    msg: any;
    model:any={};
    data:any={};
    data1:any={};
    myForm: FormGroup;
    public sample = [
     
      "Alaska",
      "Alabama",
      "Arkansas",
      "American Samoa",
      "Arizona",
      "California",
      "Colorado",
      "Connecticut",
      "District of Columbia",
      "Delaware",
      "Florida",
      "Georgia",
      "Guam",
      "Hawaii",
      "Iowa",
      "Idaho",
      "Illinois",
      "Indiana",
      "Kansas",
      "Kentucky",
      "Louisiana",
      "Massachusetts",
      "Maryland",
      "Maine",
      "Michigan",
      "Minnesota",
      "Missouri",
      "Mississippi",
      "Montana",
      "North Carolina",
      " North Dakota",
      "Nebraska",
      "New Hampshire",
      "New Jersey",
      "New Mexico",
      "Nevada",
      "New York",
      "Ohio",
      "Oklahoma",
      "Oregon",
      "Pennsylvania",
      "Puerto Rico",
      "Rhode Island",
      "South Carolina",
      "South Dakota",
      "Tennessee",
      "Texas",
      "Utah",
      "Virginia",
      "Virgin Islands",
      "Vermont",
      "Washington",
      "Wisconsin",
      "West Virginia",
      "Wyoming" 
 
      ]
    public billing_id;
    
    constructor(public account_info:account_info,private router:Router,) { }

        ngOnInit() {
          localStorage.setItem('v2','sssssssssssssssssssss');
          localStorage.setItem('details',JSON.stringify({'cmp_name':''}));
          localStorage.setItem('v3','v3');
          localStorage.setItem('v11','sssssssssss');
          this.data1.select="check"
          this.getData();
          this.active1=true;
          this.at = true; 
          this.data.check1=true;
          this.data.check2 = true;
          
        }
      
        onChange(data){
          console.log(data);
          if(data=="check"){
            this.active1 = true;
            this.active2 = false
          }else{
            this.active1 = false;
            this.active2 = true;
          }
        }
        getData(){
          this.account_info.dashboard()
          .subscribe(
            data => {
              this.beneficiary_name=data.result[0].beneficiary_name;
              this.address1 = data.result[0].address1;
              this.address2 = data.result[0].address2;
              this.country = data.result[0].country;
              this.city5 = data.result[0].city;
              
              this.state = data.result[0].state;
              this.zipe = data.result[0].zip;
              this.b_id = data.result[0].id;
              this.taxname = data.result[0].name_on_tax_return;
              this.bussinessname = data.result[0].bussiness_name;
              this.fedaralclass = data.result[0].federal_tax_classification;
              this. tax_address1 = data.result[0].tax_address1;
              this.tax_address2 = data.result[0].tax_address2;
              this.tax_country = data.result[0].tax_country;
              this.tax_city = data.result[0].tax_city;
              this.tax_state = data.result[0].tax_state;
              this.tax_zip = data.result[0].tax_zip;
              this.tax_number = data.result[0].tax_number;
              this.tax_id = data.result[0].tax_id;
              this.tax_method = data.result[0].method;
              this.pay_method = data.result[0].payment_method;
              this.bankname = data.result[0].bank_name;
              this.account_type = data.result[0].account_type;
              this.account_holder = data.result[0].account_holder;
              this.account_number = data.result[0].account_number;
              this.payto = data.result[0].payto;
              this.referance_id = data.result[0].referance_id;
              this.routing = data.result[0].routing_number;
                if(this.pay_method=="direct")
                {this.at =true;this.att = false;this.payy_method="Direct Deposit"}
                else if(this.pay_method=="check")
                {this.at =false;this.att = true;this.payy_method="Check Payment"}
                var len0 = this.account_number.length;
                var len = this.account_number.length-4;
                var len12 = this.account_number.substring(len, len0);
                var len1=this.account_number.substring(0, len);
                var ss = "";
                for(let i=0;i<len1.length;i++){
                  ss += " * ";
                    }
              this.ac_num = ss+len12;
            
              var len00 = this.routing.length;
              var lenn = this.routing.length-4;
              var len123 = this.routing.substring(lenn, len00);
              var len11=this.routing.substring(0, lenn);
              var sss = "";
              for(let i=0;i<len11.length;i++){
                sss += " * ";
                  }
            this.ac_routing = sss+len123;
            }
          );
        }
        // overview(){
        //   this.taboverview=true;
        //   this.tabbill=false;        
        //   this.tabpay=false;
        //   this.tabinfo=false;
          
        // }
        show(data){
          
         console.log(data);
         if(data==true){
           this.ad=this.address1.replace(/,/g,'');
          this.data.address = this.ad;
          this.data.addresss2 =this.address2;
          this.data.cityy = this.city5;
          this.data.zipp = this.zipe;
          console.log(this.state);
          this.data.state = this.state;
         }else{
          this.data.address = "";
          this.data.addresss2 ="";
          this.data.cityy = "";
          this.data.zipp = "";
          this.data.state = this.state;
         }
         
        }
        billing_edit()
        {
          this.taboverview=false;
          console.log(this.state);
          this.model.Bname =this.beneficiary_name;
          this.model.addresss=this.address1;
          this.model.addresss2 =this.address2;
          this.model.city = this.city5;
          this.model.zip = this.zipe;
          this.model.count1 = this.country;
          this.model.statee = this.state;
          // alert("hello");
          //this.account_info.billing_info(this.model,this.b_id)
          this.billing_id = this.b_id;
          this.tabbill=true;
          
        }
  billsubmit(){
    //console.log(1);
    
    this.tabbill=false;
    this.taboverview=true;
    this.beneficiary_name = this.model.Bname;
    let comma = JSON.stringify(this.model.addresss).indexOf(',');
    let comma1 = JSON.stringify(this.model.addresss2).indexOf(',');
    let comma2 = JSON.stringify(this.model.city).indexOf(',');
    if(comma==-1)
    {this.address1=this.model.addresss+',';}
    else{
      
      this.address1=this.model.addresss;
    }
    if(comma1==-1)
    // {this.address2=this.model.addresss2+',';}
    {this.address2=this.model.addresss2;}
    else{
      
      this.address2=this.model.addresss2;
    }
    if(comma2==-1)
    {this.city5= this.model.city;}
    else{
      
      this.city5= this.model.city;
    }
  
    this.zipe= this.model.zip;
    this.country=this.model.count1; 
    this.state=this.model.statee; 
    this.account_info.billing_info(this.model,this.billing_id)
    .subscribe(
      data => { this.msg = data.msg;this.t=data ;console.log(this.msg)},
      err => console.log(err),
      ()=>{
        if(this.msg ==0||this.msg==undefined)
        {
          alert(this.t);
        }else{
         // window.location.reload();
        console.log("success")
         // alert("ok")
        }
      }
     );
  }
  tax_edit(){
    this.taboverview=false;
    // console.log(this.state)
    this.data.tax = this.taxname;
    this.data.bussiness = this.bussinessname;
    this.data.address = this.tax_address1;
    this.data.addresss2 = this.tax_address2;
    this.data.cityy = this.tax_city;
    this.data.zipp = this.tax_zip;
    this.data.x=this.fedaralclass;
    this.data.radio =this.tax_method;
    this.data.taxid = this.tax_number;
    this.taxx_id = this.tax_id;
    this.data.state = this.tax_state;
    this.tabinfo=true;
    
  }
  taxsubmit(){
   
    this.tabinfo=false;
    this.taboverview=true;

     this.taxname=this.data.tax ;
     this.bussinessname=this.data.bussiness ;
     let commaa = JSON.stringify(this.data.address).indexOf(',');
    //  let comma1 = JSON.stringify(this.data.address2).indexOf(',');
    //  let comma2 = JSON.stringify(this.data.cityy).indexOf(',');
     if(commaa==-1)
     {this.tax_address1=this.data.address+',';}
     else{
       
      this.tax_address1=this.data.address;
     }
    //  if(comma1==-1)
    //  { this.tax_address2=this.data.address2;}
    //  else{
       
    //   this.tax_address2=this.data.address2;
    //  }
    //  if(comma2==-1)
    // //  {this.address1=this.model.addresss+',';}
    //  {this.tax_city=this.data.cityy;}
    //  else{
       
    //   this.tax_city=this.data.cityy;
    //  }
    //  this.tax_address1=this.data.address+',';
     this.tax_address2=this.data.addresss2;
     this.tax_city=this.data.cityy;
     this.tax_zip=this.data.zipp;
     this.tax_id=this.taxx_id ;
     this.fedaralclass = this.data.x;
     this.tax_state=this.data.state;
     this.tax_number = this.data.taxid;
     this.tax_method = this.data.radio;
    this.account_info.tax_info(this.data, this.taxx_id)
    .subscribe(
      data => { this.msg1= data.msg;this.t1=data ;console.log(this.msg1)},
      err => console.log(err),
      ()=>{
        if(this.msg1 ==0||this.msg1==undefined)
        {
          alert(this.t1);
        }else{
          // this.router.navigate( ['/AccountComponent']);
          // window.location.reload();
          console.log("success");
        }
      }
     );
  }
  pay_edit(){
    if(this.pay_method=="direct")
    { 
      this.referance_idd = this.referance_id;
      this.active1 = false;
      this.active2 = true;
      this.data1.Bankname =this.bankname;
      this.data1.type=this.account_type;
      this.data1.acname =this.account_holder;
      this.data1.ac = this.account_number;
      this.data1.routing = this.routing;
     this.data1.select = "direct";
    }
    else if(this.pay_method=="check")

    { 
      this.data1.select = "check";
      this.data1.pay =this.payto; 
      this.referance_idd = this.referance_id;
      this.active1 = true;
      this.active2 = false;
      
    }

  }
  logout(){
    //  alert("hi")
    this.router.navigate(['/login']);
    sessionStorage.clear();
    localStorage.clear();
    localStorage.setItem('verify',JSON.stringify({verify_id:0}));
    localStorage.setItem('currentvalue', JSON.stringify({state:"NC",city:"Releigh"}));

  }
  payy()
   {
    if( this.data1.select=="direct")
    { 
      this.referance_idd = this.referance_id;
      this.pay_method="direct";
      this.at =true;this.att = false;
       this.payy_method="Direct Deposit";
      this.bankname = this.data1.Bankname;
      this.account_type = this.data1.type;
      this.account_holder=this.data1.acname ;
      this.account_number=this.data1.ac ;
      this.routing=this.data1.routing ;
      this.data1.select = "direct";
    }
    else if( this.data1.select=="check")

    { 
      this.pay_method="check";
      this.data1.select = "check";
      this.payto=this.data1.pay ; 
      this.at =false;this.att = true;
      this.payy_method="Check Payment";
      this.referance_idd = this.referance_id;
      
      
    }
      var len0 = this.account_number.length;
      var len = this.account_number.length-4;
      var len12 = this.account_number.substring(len, len0);
      var len1=this.account_number.substring(0, len);
      var ss = "";
    for(let i=0;i<len1.length;i++){
      ss += " * ";
        }
          this.ac_num = ss+len12;

          var len00 = this.routing.length;
          var lenn = this.routing.length-4;
          var len123 = this.routing.substring(lenn, len00);
          var len11=this.routing.substring(0, lenn);
          var sss = "";
          for(let i=0;i<len11.length;i++){
            sss += " * ";
              }
        this.ac_routing = sss+len123;
     console.log(this.referance_idd);
     this.account_info.payment(this.data1,this.referance_idd)
     .subscribe(
       data => { this.msg2= data.msg;this.t2=data ;console.log(this.msg1)},
      err => console.log(err),
       ()=>{
         if(this.msg2 ==0||this.msg2==undefined)
         {
          alert(this.t2);
         }else{
  //         // this.router.navigate( ['/AccountComponent']);
          // window.location.reload();
          console.log("pay success");
          
      
        }
       }
      );
    
   }
}
