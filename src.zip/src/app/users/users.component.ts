import { Component, OnInit,ViewChild } from '@angular/core';
import { user } from '../service/user';
import { FormsModule,ReactiveFormsModule,NG_VALIDATORS,Validator,Validators,AbstractControl,ValidatorFn, NgForm } from '@angular/forms';

import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  msg: any;
  login_msg: boolean;
  d: any;
  sub_merchant_id: any;
  userDetails=[];
  
  model:any={}
  mask: any[] = ['+', '1', ' ', '(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  constructor(private user:user,private router:Router) { }
  
  ngOnInit() {
   this.getuserdata();
  }

  gv(user){
    // alert(user.sub_merchant_id);
    this.d =user.sub_merchant_id;
  }
  logout(){
    //  alert("hi")
    this.router.navigate(['/login']);
    sessionStorage.clear();
    localStorage.clear();
    localStorage.setItem('verify',JSON.stringify({verify_id:0}));
    localStorage.setItem('currentvalue', JSON.stringify({state:"NC",city:"Releigh"}));

  }
  getuserdata(){
    // this.userDetails=[];
    this.user.getuserdata()
    .subscribe(
      data=>{
        // console.log(data.results)
        this.userDetails=data.results;
      // for(let i=0;i<data.results.length;i++){
      //   let sub_merchant_id = data.results[i].sub_merchant_id;
      //   let firstname = data.results[i].firstname;
      //   let lastname = data.results[i].lastname;
      //   let create_date = data.results[i].create_date;
      //   let email = data.results[i].email;
      //   let mob = data.results[i].mobile;
      //   let password=data.results[i].password;
      //   this.userDetails.push({
      //     sub_merchant_id:sub_merchant_id,
      //     firstname:firstname,
      //     lastname:lastname,
      //     create_date:create_date,
      //     email:email,
      //     mob:mob,
      //     password:password,
      //   });
        
      // }
      console.log(this.userDetails);
      }
    );

  }
  edit1(){
    this.user.edit(this.model,this.sub_merchant_id)
    .subscribe(
      data=>{
        console.log(data.results);
        (data.results==1)?this.getuserdata():console.log("update fail")
      }
    );
  }
  clear(){
    this.model.fname = "";
    this.model.lname = "";
    this.model.gmail = "";
    this.model.password = "";
    this.model.call =""; 
  }
  edit(data){
    // alert(data.sub_merchant_id);
    this.sub_merchant_id = data.sub_merchant_id;
    this.model.fname = data.firstname;
    this.model.lname = data.lastname;
    this.model.gmail = data.email;
    this.model.password = data.password;
    this.model.call = data.mob; 
  }
  delete(){
    // alert(this.d);
    this.sub_merchant_id = this.d;
    this.user.delete(this.sub_merchant_id)
    .subscribe(
      data=>{
        console.log(data.results);
        (data.results==1)?this.getuserdata():console.log("delete fail")
      }
    );
  }
  cheking(){
    //alert("check");
    this.user.ch(this.model)
    .subscribe(
      data => { this.msg = data.msg; console.log(data)},
      err => console.log(err),
      () => {if(this.msg==0)
      {console.log("Email already exists");
      this.login_msg=true;
      setTimeout(()=>{ this.login_msg = false; },2000);}
      else{console.log("okey");}});
   
  }
  addsub_user(){
    // console.log(this.model);
    this.user.sub_user(this.model)
    .subscribe(
      data=>{
        console.log(data)
        this.getuserdata();
      }
    );
    
  }
}
