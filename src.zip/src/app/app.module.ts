import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule,Http} from '@angular/http';
import {ModalModule} from "ng2-modal";
import { RouterModule, Router, Params,ActivatedRoute } from '@angular/router';
import {AppRoute} from './app.routes';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { IndexComponent } from './index/index.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { StoresComponent } from './stores/stores.component';
import { AddstoresComponent } from './addstores/addstores.component';
import { VerifybreweryComponent } from './verifybrewery/verifybrewery.component';
import { BrewerydetailsComponent } from './brewerydetails/brewerydetails.component';
import {RatingModule} from "ng2-rating";
import { signup,authentication,account_info,Ai_authentication,Loginauth,
  shops,user,verify,ver2,ver3,current,review} from './service/index';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';

import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { Ng2MapModule} from 'ng2-map';
import { MerchantSignupComponent } from './merchant-signup/merchant-signup.component';
import { TermsConditionsComponent } from './terms-conditions/terms-conditions.component';
import { EqualValidator } from './equal-validator.directive';
import { TextMaskModule } from 'angular2-text-mask';
import { ClickOutsideModule } from 'ng-click-outside';
import { PersonSearchPipe  } from './pipe';
import {enableProdMode} from '@angular/core';
import { Verifybrewary2Component } from './verifybrewary2/verifybrewary2.component';
import { Verifybrewary3Component } from './verifybrewary3/verifybrewary3.component';
import { AccountInformationComponent } from './account-information/account-information.component';
import { Header2Component } from './header2/header2.component';
import { AccountComponent } from './account/account.component';
import { NguiAutoCompleteModule } from '@ngui/auto-complete';
import { TestComponent } from './test/test.component';
import { MatFormFieldModule } from '@angular/material';
import { MatInputModule } from '@angular/material';
import { MatSelectModule } from '@angular/material';


import { MatCheckboxModule,MatRadioModule,MatButtonModule,MatProgressSpinnerModule } from '@angular/material';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { UsersComponent } from './users/users.component';
import { PaymentsComponent } from './payments/payments.component';
import { ReportingComponent } from './reporting/reporting.component';
import { PhotoVideoComponent } from './photo-video/photo-video.component';
import { ChartsModule } from 'ng2-charts/ng2-charts';



enableProdMode();
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    IndexComponent,
    HeaderComponent,
    FooterComponent,
     
    LoginComponent,
    ReportingComponent,
    UsersComponent,
    PaymentsComponent,
    MerchantSignupComponent,
    PrivacyPolicyComponent,
    TermsConditionsComponent,
    EqualValidator,
    VerifybreweryComponent,
    BrewerydetailsComponent,
    PersonSearchPipe,
    Verifybrewary2Component,
    Verifybrewary3Component,
    AccountInformationComponent,
    Header2Component,
    AccountComponent,
    TestComponent,
    StoresComponent,
    AddstoresComponent,
    PhotoVideoComponent,
   
    
  ],
  imports: [
    MatProgressSpinnerModule,
    ChartsModule,
    MatRadioModule,
    MatCheckboxModule,
    MatSelectModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    BrowserModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    ModalModule,
    RatingModule,
    TextMaskModule,
    ClickOutsideModule,
    NguiAutoCompleteModule,
 
    Ng2MapModule.forRoot({apiUrl: 'https://maps.google.com/maps/api/js?key=AIzaSyAtrjoskEoY3e9MZsBWD3DVlXa-k5XCQqU'}),
    // AIzaSyAtrjoskEoY3e9MZsBWD3DVlXa-k5XCQqU
    // https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=CmRaAAAAbm2erX9PWwYPsu_TaI-WTItZmXwFKhgwfKXhtRfoiZT5iMRMUCUDK9lp7-gFSqp1kNPTQoVCtAvFn4D2nlxXzTzYzYsNm7ZwdDpmMkng452Bi5fQ-dJAcGbt0rrxXlrGEhCdX_GUlph5XjJFIfhEfP-pGhRI4ec4BFbVSbvL26LrUvVVrxd1rQ&key=YOUR_API_KEY
    RouterModule.forRoot(AppRoute,{ useHash: true })
  ],
  providers: [signup,authentication,account_info,Ai_authentication,Loginauth,shops,user,verify,ver2,ver3,current,review],
  // providers: [{provide: LocationStrategy, useClass: HashLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
