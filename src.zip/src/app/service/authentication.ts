import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { Observable } from 'rxjs/Rx';

@Injectable()
export class authentication implements CanActivate {

    constructor(private router: Router) { }

    canActivate() {
        // localStorage.setItem('verify',JSON.stringify({verify_id:0}));
        const value = localStorage.getItem('admin');
        const v3 = localStorage.getItem('v3');
        console.log(value);
        if (value == null && v3 == null) {
            // alert(value);
            //this.router.navigate(['/VerifybreweryComponent']);
            localStorage.setItem('verify',JSON.stringify({verify_id:0}));
            this.router.navigate(['/login']);
            return  false;
        } else {
            localStorage.setItem('verify',JSON.stringify({verify_id:1}));
            
            return true;
        }
    }
}
