import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/map';

@Injectable()
export class account_info {
   
    activeurl: string;

    constructor(
        private http: Http,
        private router: Router,
        ) {}        
         

    billing_info(model,billing_id) 
    {
        const value = localStorage.getItem('admin');
        var  b_id;
        //console.log(model);
       if(billing_id==undefined||billing_id==null)
       {
            b_id= "";
       }else
       {
            b_id=billing_id;
       }
        console.log(b_id);
                //const data = [];
        //const data = JSON.stringify('email');
      // alert(b_id);
        const formData: FormData = new FormData();
        formData.append('beneficiary_name',model.Bname);
        formData.append('address1',model.addresss);
        formData.append('address2',model.addresss2);
        formData.append('country',model.count1);
        formData.append('city',model.city);
        formData.append('state',model.statee);
        formData.append('zip',model.zip);
        formData.append('id',b_id);
        formData.append('user_id',value);
        
        // const header = new Headers();
        //   //header.append( 'Content-Type', 'application/x-www-form-urlencoded');
        //   header.append('Access-Control-Allow-Origin', '*');
        console.log(formData);
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Billing', formData)
                .map((res: Response) => res.json())
                
    }
    tax_info(data,tax_id){
        console.log(data.radio);
        var taxx_id ;
        if(tax_id==undefined)
        {
            taxx_id= "";
        }else
        {
            taxx_id=tax_id;
        }
        //const data = [];
        //const data = JSON.stringify('email');
        const value = localStorage.getItem('admin');
        const formData: FormData = new FormData();
        formData.append('tax_return',data.tax);
        formData.append('bussiness_name',data.bussiness);
        formData.append('tax_clasification',data.x);
        formData.append('address1',data.address);
        formData.append('address2',data.addresss2);
        formData.append('country',"usa");
        formData.append('city',data.cityy);
        formData.append('state',data.state);
        formData.append('zip',data.zipp);
        formData.append('id',taxx_id);
        formData.append('user_id',value);
        formData.append('method',data.radio);
        formData.append('tax_number',data.taxid);
        formData.append('check1',data.check1);
        formData.append('check2',data.check2);
        // const header = new Headers();
        //   //header.append( 'Content-Type', 'application/x-www-form-urlencoded');
        //   header.append('Access-Control-Allow-Origin', '*');
          //console.log(formData);
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/tax', formData)
                .map((res: Response) => res.json())
                
    }
    payment(data1,referance_id)
    {
        console.log(data1);
        var referance ;
        if(referance_id==undefined)
        {
            referance= "";
        }else
        {
            referance=referance_id;
        }
        console.log(referance);
        //const data = [];
        //const data = JSON.stringify('email');
        const value = localStorage.getItem('admin');
        const formData: FormData = new FormData();
        formData.append('payment_method',data1.select);
        formData.append('payto',data1.pay);
        formData.append('mailto',"data1.mailto");
        formData.append('bank_name',data1.Bankname);
        formData.append('account_type',data1.type);
        formData.append('account_holder',data1.acname);
        formData.append('account_number',data1.ac);
        formData.append('routing_number',data1.routing);
        formData.append('user_id',value);
        formData.append('id',referance);
        // const header = new Headers();
        //   //header.append( 'Content-Type', 'application/x-www-form-urlencoded');
        //   header.append('Access-Control-Allow-Origin', '*');
          //console.log(formData);
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Payment', formData)
                .map((res: Response) => res.json())
    }
    dashboard(){
        const value = localStorage.getItem('admin');
        const formData:FormData = new FormData();
        formData.append('user_id',value);
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Ai_dashboard',formData)
        .map((res:Response)=>res.json())

    }

}