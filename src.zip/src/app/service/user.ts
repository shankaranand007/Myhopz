import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import 'rxjs/add/operator/map';

@Injectable()
export class user {
   
    activeurl: string;

    constructor(
        private http: Http,
        private router: Router,
        ) {}   
        sub_user(model) {
            const value = localStorage.getItem('admin');
            // console.log(model+"sdf"+value);
            let day = moment().format('DD/MM/YYYY');
            
            // alert(day);

            const formData: FormData = new FormData();
            formData.append('firstname',model.fname);
            formData.append('lastname',model.lname);
            formData.append('email',model.gmail);
            formData.append('mobile',model.call);
            formData.append('date',day);
            formData.append('password',model.password);
            formData.append('user_id',value);
            return this.http.post('https://myhopz.com/myhopz_dev/index.php/User', formData)
            .map((res: Response) => res.json())
        }
        ch(model) {
            const value = localStorage.getItem('admin');
       
            console.log(model.gmail);
            const formData: FormData = new FormData();
          
            formData.append('email',model.gmail);
            
            return this.http.post('https://myhopz.com/myhopz_dev/index.php/user/mail', formData)
            .map((res: Response) => res.json())
        }
        getuserdata(){
            const value = localStorage.getItem('admin');
            const formData = new FormData();
            formData.append('user_id',value);
            return this.http.post('https://myhopz.com/myhopz_dev/index.php/User/getuserDetails', formData)
            .map((res: Response) => res.json())
        }
        edit(model,data){
            const formData: FormData = new FormData();
            formData.append('firstname',model.fname);
            formData.append('lastname',model.lname);
            formData.append('email',model.gmail);
            formData.append('mobile',model.call);
            formData.append('sub_merchant_id',data);
            formData.append('password',model.password);
            
            return this.http.post('https://myhopz.com/myhopz_dev/index.php/User/userEdit', formData)
            .map((res: Response) => res.json())
        }
        delete(data){
            const formData:FormData = new FormData();
            formData.append('sub_merchant_id',data);
            return this.http.post('https://myhopz.com/myhopz_dev/index.php/User/userDelete', formData)
            .map((res: Response) => res.json())
        }
    }