import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { Observable } from 'rxjs/Rx';

@Injectable()
export class ver3 implements CanActivate {

    constructor(private router: Router) { }

    canActivate() {
       var ss = localStorage.getItem('v2');
       console.log(ss);
       if(ss == "ss"){
        // this.router.navigate(['/Verifybrewary3Component']);
        return true;
       }else{
        this.router.navigate(['/login']);
       return false;
       }
      
    }
}
