import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/map';

@Injectable()
export class current {
    location = {};
    city: any;
    state: any;
   
    activeurl: string;

    constructor(
        private http: Http,
        private router: Router,
        ) {}        
    local(){
        var lati2;
        var logi2;
        if(navigator.geolocation){
          navigator.geolocation.getCurrentPosition(position => {
            this.location = position.coords;
           lati2= position.coords.latitude;
           logi2= position.coords.longitude;
    
          var lat =lati2;
          var lng = logi2 ;
            const header = new Headers();
            // header.append( 'Content-Type', 'application/json');
             header.append('Access-Control-Allow-Origin', '*');
             header.append('Access-Control-Allow-Origin', 'http://localhost:4200');
             header.append('Access-Control-Request-Method', 'POST');
             header.append('Access-Control-Allow-Headers:application/json',' Content-Type');
    
            this.http.get('https://maps.googleapis.com/maps/api/geocode/json?latlng='+lat+','+lng)
            .map((res: Response) => res.json())
            .subscribe(
              data => { console.log(data.results[0]);
                
                            var len = parseInt(data.results[0]['address_components'].length);
                            
                             var len2 = len-3;
                             var len3 = len-4;
                            var country=data.results[0]['address_components'][7].short_name;
                             this.state=data.results[0]['address_components'][len2].short_name;
                             this.city=data.results[0]['address_components'][len3].long_name;
                             localStorage.setItem('currentvalue', JSON.stringify({state:this.state,city:this.city}));
                          
              });
            });
            }
        console.log("current"+this.state,this.city);
           
    }
    } 
  