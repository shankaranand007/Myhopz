import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';

import 'rxjs/add/operator/map';

@Injectable()
export class signup {
   
    activeurl: string;

    constructor(
        private http: Http,
        private router: Router,
        ) {}        
         

    signup(model) {
        console.log(model);
        //const data = [];
        //const data = JSON.stringify('email');
       
        const formData: FormData = new FormData();
        formData.append('firstname',model.firstname);
        formData.append('lastname',model.lastname);
        formData.append('email',model.mail);
        formData.append('password',model.password);
        formData.append('mobile_number',model.mobile);
        
        // const header = new Headers();
        //   //header.append( 'Content-Type', 'application/x-www-form-urlencoded');
        //   header.append('Access-Control-Allow-Origin', '*');
          //console.log(formData);
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Signup', formData)
                .map((res: Response) => res.json())
                
         }
     login(model){
            const formData: FormData = new FormData();
           
            formData.append('email',model.mail);
            formData.append('password',model.password);
     return this.http.post('https://myhopz.com/myhopz_dev/index.php/Signup/signin', formData)
            .map((res: Response) => res.json())
            
         }

}
