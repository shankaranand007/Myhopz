import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';

import 'rxjs/add/operator/map';

@Injectable()
export class review {
   
    activeurl: string;

    constructor(
        private http: Http,
        private router: Router,
        ) {} 
        
        getReview(shop_id){
            const formData: FormData = new FormData();
            formData.append('shop_id',shop_id);
            return this.http.post('https://myhopz.com/myhopz_dev/index.php/Review',formData)
            .map((res: Response) => res.json())
        }
        getImgg(shop_id){
            const formData: FormData = new FormData();
            formData.append('shop_id',shop_id);
            return this.http.post('https://myhopz.com/myhopz_dev/index.php/Brewary/getImg2',formData)
            .map((res: Response) => res.json())

        }
        hide_review(review,shop){
            const formData: FormData = new FormData();
            formData.append('shop_id',shop);
            formData.append('review_id',review);
            return this.http.post('https://myhopz.com/myhopz_dev/index.php/Review/hide',formData)
            .map((res: Response) => res.json())
        }
    }