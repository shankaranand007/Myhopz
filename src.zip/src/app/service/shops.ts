import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';

import 'rxjs/add/operator/map';

@Injectable()
export class shops {
   
    activeurl: string;

    constructor(
        private http: Http,
        private router: Router,
        ) {}        
       
    claim(data){
        const value = localStorage.getItem('admin');
        console.log("service"+data);
        const formData: FormData = new FormData();
        formData.append('user_id',value);
        formData.append('shop_id',data.shop_id);
        formData.append('storetime',data.storetime);
        formData.append('phone',data.phone);
        formData.append('lat',data.lattt);
        formData.append('longg',data.lnggg);
        formData.append('state',data.state);
        formData.append('zip',data.zipcode);
        formData.append('countryname',data.country);
        formData.append('city',data.city);
        formData.append('website',data.website);
        formData.append('image',data.img);
        formData.append('address',data.address);
        formData.append('shop_name',data.cmp_name);
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Claiming', formData)
        .map((res: Response) => res.json())
        
 
    }
    // activate(){
    //     const value = localStorage.getItem('admin');
    // }
    claimed(){
        const value = localStorage.getItem('admin');
        const formData: FormData = new FormData();
        formData.append('user_id',value);

        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Claiming/getClaimed', formData)
        .map((res: Response) => res.json())
    }
    beerprice(data,shop_id){
        // console.log(data.weekmin+"hiiii"+shop_id);
        const value = localStorage.getItem('admin');
        // console.log(data);
        const formData: FormData = new FormData();
        formData.append('user_id',value);
        formData.append('shop_id',shop_id);
        formData.append('week_min',data.weekmin);
        formData.append('week_max',data.weekmax);
        formData.append('weekend_min',data.weekendmin);
        formData.append('weekend_max',data.weekendmax);
        formData.append('week_price',data.weekdayprice);
        formData.append('weekend_price',data.weekendprice);
       
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Claiming/beer', formData)
        .map((res: Response) => res.json())
        

    }
    getbeerprice(shop_id){
        const value = localStorage.getItem('admin');
        // console.log("shankar"+shop_id+value);
        const formData: FormData = new FormData();
        formData.append('user_id',value);
        formData.append('shop_id',shop_id);
       

        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Claiming/getPrice', formData)
        .map((res: Response) => res.json())
    }
    media_upload(data,shop_id){
        const value = localStorage.getItem('admin');
        console.log(data[0]);
        const formData: FormData = new FormData();
        const file: File = data[0];
        formData.append("user_id",value);
        formData.append("shop_id",shop_id);
        formData.append('brewary_image',file);
       
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Brewary/uploadImage', formData)
        .map((res: Response) => res.json())
    }
    logo(data,shop_id){
        const value = localStorage.getItem('admin');
        console.log(data[0]);
        
        const formData: FormData = new FormData();
        const file: File = data[0];
        // formData.append("user_id",value);
        formData.append("shop_id",shop_id);
        formData.append('logo',file);
       
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Brewary/logo', formData)
        .map((res: Response) => res.json())
    }
    getImg(shop_id){
        const value = localStorage.getItem('admin');
        // console.log(data[0]);
        const formData: FormData = new FormData();
        
       
        formData.append("shop_id",shop_id);
        
       
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Brewary/getImg', formData)
        .map((res: Response) => res.json())
    }
    delImg(data){
        console.log("service"+data);
        var js = JSON.stringify(data);
        const formData: FormData = new FormData();
        formData.append("del",js);

        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Brewary/imgdelete', formData)
        .map((res: Response) => res.json())

    }
    }