import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { Observable } from 'rxjs/Rx';

@Injectable()
export class Ai_authentication implements CanActivate {

    constructor(private router: Router) { }

    canActivate() {
        const value = JSON.parse(localStorage.getItem('verify'));
        var vl = value.verify_id;
        //alert(vl)
        console.log(vl);
        if (vl ==1 && vl!==null) {
            // alert(value);
            // this.router.navigate(['/MerchantDetails']);
            
            return  true;
        } else {
            
            this.router.navigate(['/login']);
            return false;
        }
    }
}
