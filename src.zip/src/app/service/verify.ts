import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';

import 'rxjs/add/operator/map';

@Injectable()
export class verify {
   
    activeurl: string;

    constructor(
        private http: Http,
        private router: Router,
        ) {}    
  
  
   verify1(mob,otp){
        // console.log(mob+"  "+otp);
        const value = localStorage.getItem('admin');
        // console.log(value);
        const formData: FormData = new FormData();
        formData.append('otp',otp);
        formData.append('mob_number',mob);
        formData.append('user_id',value);
       
        // formData.append('otp','54321');
        // formData.append('mob_number','7502824066');
        // formData.append('user_id',value);
       
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Verify/verify', formData)
        .map((res: Response) => res.json())
        
    }

    intervel(mob,otp){
        // console.log("inter");
        const formData: FormData = new FormData();
        formData.append('otp',otp);
        formData.append('mob_number',mob);
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Verify/move', formData)
        .map((res: Response) => res.json())
    }
    ph(mob,otp){
        console.log('test'+mob)
        const formData: FormData = new FormData();
        formData.append('otp',otp);
        formData.append('mob_number',mob);
        return this.http.post('https://myhopz.com/myhopz_dev/index.php/Verify/call', formData)
        .map((res: Response) => res.json())
    }
    }   