import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { Observable } from 'rxjs/Rx';

@Injectable()
export class ver2 implements CanActivate {

    constructor(private router: Router) { }

    canActivate() {
       const s = localStorage.getItem('v11');
       console.log(s);
       if(s=='s'){
        // this.router.navigate(['/Verifybrewary2Component']);
        return true;
       }else{
        this.router.navigate(['/login']);
           return false;
       }
      
    }
}
