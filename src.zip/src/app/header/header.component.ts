import { Component, OnInit } from '@angular/core';
import {  ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  vl: any;

  public inactive: boolean;
  public active: boolean;

  constructor(private router:Router) { 
    
  }

  ngOnInit() {
    const value = JSON.parse(localStorage.getItem('verify'));
    this.vl = value.verify_id;
    console.log( value.verify_id);
    this.getData();
  }
  getData(){
    
    if(this.vl==0)
    {
      this.active=true;
      this.inactive=false;
    }else{
      this.active = false;
      this.inactive = true;
    }
   
  }
  logout(){
    //  alert("hi")
    this.router.navigate(['/login']);
    sessionStorage.clear();
    localStorage.clear();
    localStorage.setItem('verify',JSON.stringify({verify_id:0}));
    localStorage.setItem('currentvalue', JSON.stringify({state:"NC",city:"Releigh"}));

  }
}
