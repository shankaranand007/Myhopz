import {Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'requestSearch'
})
export class PersonSearchPipe implements PipeTransform {
    transform(items: Array<{state: string,city:string,shopname:string,latitude:number,zipcode:string}>, nameSearch: string){
        
        if (items && items.length > 0){
            return items.filter(item =>{
                if (nameSearch  && item.state.toLowerCase().indexOf(nameSearch.toLowerCase()) === -1
                     &&nameSearch  && item.city.toLowerCase().indexOf(nameSearch.toLowerCase()) === -1
                     &&nameSearch  && item.zipcode.indexOf(nameSearch) === -1
                   
                     ){
                    return false;
                }
                return true;
           })
        }
        else{
            return items;
        }
    }
    //  {
    // this.setState({searchValue:text})
    // var location = this.state.markerOriginal

    //   var filterValue = location.filter(function(searchWord){
    //     return searchWord['zipcode'].toLowerCase().indexOf(text) != -1 || searchWord['city'].toLowerCase().indexOf(text) != -1 || searchWord['state'].toLowerCase().indexOf(text) != -1

    //   });

    // transform(items: any[], criteria: any): any {
        
    //             return items.filter(item =>{
    //                for (let key in item ) {
    //                  if((""+item[key]).includes(criteria)){
    //                     return true;
    //                  }
    //                }
    //                return false;
    //             });
    //         }
}