import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Verifybrewary3Component } from './verifybrewary3.component';

describe('Verifybrewary3Component', () => {
  let component: Verifybrewary3Component;
  let fixture: ComponentFixture<Verifybrewary3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Verifybrewary3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Verifybrewary3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
