import { Component, OnInit } from '@angular/core';
import { shops } from '../service/shops';
import { Router } from '@angular/router';
@Component({
  selector: 'app-verifybrewary3',
  templateUrl: './verifybrewary3.component.html',
  styleUrls: ['./verifybrewary3.component.css']
})
export class Verifybrewary3Component implements OnInit {
  details: any;
  mobile_number: any;
  img: any;
  zipcode: any;
  country: any;
  state: any;
  city: any;
  address: any;
  cmp_name: any;

  constructor(private router:Router,public shops:shops,) { }

  ngOnInit() {
    localStorage.setItem('v11','sssssssssss');

    this.details = JSON.parse(localStorage.getItem('details'));
    this.cmp_name = this.details.cmp_name;
    this.address = this.details.address;
    this.city= this.details.city;
    this.state=this.details.state;
    this.country = this.details.country;
    this.zipcode = this.details.zipcode;
    this.img = this.details.img;
    this.mobile_number = this.details.phone;
  }
next(){
  console.log(this.details)
  this.shops.claim(this.details)
      .subscribe(
         data => {console.log(data)
        
          this.router.navigate(['/MerchantDetails'])
        },
       );
  
}
}
