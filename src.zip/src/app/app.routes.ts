import { Routes, RouterModule } from '@angular/router';
//import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { IndexComponent } from './index/index.component';
import { MerchantSignupComponent } from './merchant-signup/merchant-signup.component';
import { TermsConditionsComponent } from './terms-conditions/terms-conditions.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { VerifybreweryComponent } from './verifybrewery/verifybrewery.component';
import { Verifybrewary2Component } from './verifybrewary2/verifybrewary2.component';
import { Verifybrewary3Component } from './verifybrewary3/verifybrewary3.component';
import { BrewerydetailsComponent } from './brewerydetails/brewerydetails.component';
import { authentication ,Ai_authentication,Loginauth,ver2,ver3} from './service/index';
import { AccountComponent } from './account/account.component';
import { TestComponent } from './test/test.component';
import { StoresComponent } from './stores/stores.component';
import { AccountInformationComponent } from './account-information/account-information.component';
import { AddstoresComponent } from './addstores/addstores.component';
import { UsersComponent } from './users/users.component';
import { PaymentsComponent } from './payments/payments.component';
import { ReportingComponent } from './reporting/reporting.component';
import { PhotoVideoComponent } from './photo-video/photo-video.component';

 export const AppRoute: Routes = [


     {
         path : '',
         children: [
            { path: '',  redirectTo: 'home', pathMatch: 'full',},
            { path: 'home',   component : HomeComponent},
            { path: 'map', component: IndexComponent },
            { path: 'terms', component: TermsConditionsComponent },
            { path: 'privacy', component: PrivacyPolicyComponent },
            { path: 'BrewerydetailsComponent', component: BrewerydetailsComponent }
          ]
     },
     {
      path : "test",
      component : TestComponent
      },
    
     {
     
       path: 'Signup',
       canActivate: [Loginauth],
       component:MerchantSignupComponent
     },
     {
     
       path: 'login',
       canActivate: [Loginauth],
       component: LoginComponent
     },
   
    {
      path:'VerifybreweryComponent',
           
      canActivate: [authentication],
      component: VerifybreweryComponent
     
    },
    
    {
      path:'Verifybrewary2Component',
       canActivate: [ver2],
       component: Verifybrewary2Component
    },
    {
        path:'Verifybrewary3Component',
        canActivate: [ver3],
        component: Verifybrewary3Component
    },
    {
      path:'MerchantDetails',
     component: AccountComponent,
      canActivate: [Ai_authentication],
      children: [
        { path: '', redirectTo: 'details', pathMatch: 'full'},
        { path: 'details',   component : AccountInformationComponent,},
        { path: 'addstore',   component : AddstoresComponent,},
        { path: 'stores',   component : StoresComponent,},
        { path: 'user',   component : UsersComponent,},
        { path: 'pay',   component : PaymentsComponent,},
        { path: 'report',   component : ReportingComponent,},
        { path: 'media',   component : PhotoVideoComponent,},
        ]
      
    },
   
    { path: '**', redirectTo: 'home' },
    
 ];
 