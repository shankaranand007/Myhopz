import { Component, OnInit,ViewChild } from '@angular/core';
import { shops } from '../service/shops';
import {FormArray,FormControl, FormGroup,FormBuilder,FormsModule,ReactiveFormsModule,NG_VALIDATORS,Validator,Validators,AbstractControl,ValidatorFn, NgForm } from '@angular/forms';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';
import { review } from '../service/review';

@Component({
  selector: 'app-stores',
  templateUrl: './stores.component.html',
  styleUrls: ['./stores.component.css']
})
export class StoresComponent implements OnInit {
 
  spinnar: boolean;
  display: boolean;
  display2: boolean;
  active2: boolean;
  active: boolean;
  errorFileType: boolean;
  fileEvent: any;
  fileName: any;
  selected = 'Last Day';
  arrow: boolean;
  checked2=[];
  op:any={};
  local2: any;
  optionsMap=[];
  media1=[];
  checked :Array<any> = [] ;
  allowedTypes: any;
  sizeLimit=6;
  claimed2: any[];
  beerrate: any;
  public claimed=[];
  public localvalue=[];
  pos: any;
  weekkmax="Ex:300";
  weekkmin="100"
  weekkendmax="Ex:300";
  weekkendmin="100";
  weekkprice = "0.50";
  weekkendprice="0.60";
  model:any={}; 
  item:any={}; 
  myForm: FormGroup;
  public reviewdata=[];
  constructor(private command:review,private shops:shops,private router:Router,private fb: FormBuilder) {
   }
   
  ngOnInit() {
    
    this.myForm = this.fb.group({
      id: this.fb.array([])
    });
   
    this.getData();
   
  }
  review(){
    this.command.getReview(this.localvalue)
    .subscribe(
      data=>{
        console.log(data.result)
        this.reviewdata = data.result;
        this.spinnar =false;
      }
    );
  }
  emptyclaim(){
    this.display2=true;
    this.display=false;
   this.claimed = [
        {
         
          "name_3": "Eg: BigBoss Brewary",
          "website": "Eg: www.BigBoss.com",
          "phone":"Eg: (979) 0054083",
          "address":"Eg: 14,ponniyer street",
          "country":"USA",
          "zipcode":"12124",
          "img" :"assets/images/samplee.jpg",
          "state":"NC",
          "city":"Charlotte",
        },
    ]
  }
  del(){
    console.log(this.myForm.value.id)
    console.log(this.checked);
    this.shops.delImg(this.myForm.value.id)
    .subscribe(
      data=>{
        console.log("del"+data);
        this.getImg(this.local2);
      }
    )
  }
  remove(review_id,shop_id){
    //alert(shop_id);
    this.spinnar =true;
    this.command.hide_review(review_id,shop_id)
    .subscribe(
      data=>{
        this.review();
        console.log(data.result)
        this.reviewdata = data.result;
       
        
      }
    );
  }
  updateChecked(option:string, id:string,isChecked: boolean) {
    console.log(option);
    
     this.local2=id;
      const emailFormArray = <FormArray>this.myForm.controls.id;
      
            if(isChecked) {
              emailFormArray.push(new FormControl(option));
            } else {
              let index = emailFormArray.controls.findIndex(x => x.value == option)
              emailFormArray.removeAt(index);
            }
      // console.log( this.myForm);
    
  }
getData(){
  this.shops.claimed()
  .subscribe(
    data=>{console.log(data.result)
      if(data.result.length==0){
        this.emptyclaim();
        this.arrow = false;
      }else{
        this.spinnar =true;
        this.display2=false;
        this.display=true;
        this.arrow = true;
      this.pos=data.result;
      for (let i = 0 ; i < this.pos.length; i++) {
        let value = this.pos[i];
         
          let address = value.address;
          let city = value.city;
          let countryname = value.countryname;
          let img = value.image;
          let lat = value.lat;
          let long = value.longg;
          let phone = value.phone;
          let shop_id = value.shop_id;
          let state = value.state;
          let storetime = value.storetime;
          let user_id = value.merchant_id;
          let web = value.website;
          let zip = value.zip;
          
          let shop_name = value.shop_name;
           
           this.claimed.push({lattt: lat, lnggg: long,name_3: shop_name,shop_id:shop_id,status:status,
            city:city,state:state,img:img,
            address:address,country:countryname,select:"inactive",
            zipcode:zip,storetime:storetime,
            phone:phone,
            website:web
          });
          // this.localvalue=this.claimed[0];
          
          
                          
     }
    }
    //  (this.claimed.length==0)?this.emptyclaim():console.log("not empty");
     this.localvalue =this.claimed[0].shop_id;
    //  alert(this.localvalue);
     this.claimed2 = this.claimed
     this.getbeerprice();
     this.getImg1();
     this.review();
    //  console.log(this.localvalue);
    
    
    
    }
  );
}
getImg1(){
  this.shops.getImg(this.localvalue)
  .subscribe(
    data=>{
      console.log(data);
      this.media1 = data.result;
      this.spinnar =false;
      console.log(this.media1);
    }
  )
}
getImg(value){
  this.shops.getImg(value)
  .subscribe(
    data=>{
      console.log(data);
      this.media1 = data.result;
      this.spinnar =false;
      console.log(this.media1);
    }
  )
}
getbeerprice(){
  // alert(this.localvalue);
  this.shops.getbeerprice(this.localvalue)
  .subscribe(
    data=>{
      // console.log(data.result[0])
      this.weekkmax=data.result[0].week_max;
      // this.weekkmin=data.result[0].week_min;
      this.weekkendmax=data.result[0].weekend_max;
      // this.weekkendmin=data.result[0].weekend_min;
      // this.weekkprice =data.result[0].week_price;
      // this.weekkendprice=data.result[0].weekend_price;
    }
    );
}
nxt(data){
  this.spinnar =true;
  this.reviewdata=[];
  //alert(data);
  if(this.claimed2.length == data+1){
  //  alert("hi")
    this.localvalue = this.claimed2[data].shop_id;
  
    
  } else{
   
    this.localvalue = this.claimed2[data+1].shop_id;
    
    
  }
  //this.localvalue = this.claimed2[data+1].shop_id;
  //alert(this.localvalue);
  console.log(this.claimed2.length);
  
  this.getbeerprice2(this.localvalue);
  this.getImg(this.localvalue);
  this.review();
  // alert(data);
  // this.randomize();
}
pre(data){
  this.spinnar =true;
  this.reviewdata=[];
  if(data==0){
    this.localvalue=this.claimed[this.claimed2.length-1].shop_id;
    // console.log(this.claimed[this.claimed.length-1]);
    
  } else{
    this.localvalue=this.claimed2[data-1].shop_id;
    // console.log(this.claimed[data-1]);
    
  }
   alert(this.localvalue);
  this.getbeerprice2(this.localvalue);
  this.getImg(this.localvalue);
  this.randomize();
  this.review();
}
logout(){
  this.router.navigate(['/login']);
  sessionStorage.clear();
  localStorage.clear();
  localStorage.setItem('verify',JSON.stringify({verify_id:0}));
}
getbeerprice2(value){
  // alert(value);
  this.shops.getbeerprice(value)
  .subscribe(
    data=>{
      // console.log(data.result[0])
      this.weekkmax=data.result[0].week_max;
      // this.weekkmin=data.result[0].week_min;
      this.weekkendmax=data.result[0].weekend_max;
      // this.weekkendmin=data.result[0].weekend_min;
      // this.weekkprice =data.result[0].week_price;
      // this.weekkendprice=data.result[0].weekend_price;
    }
    );
}
upload_is(){
  this.router.navigate( ['/MerchantDetails/media',{shop_id:this.localvalue}]);
}

beerprice(){
  // console.log(this.localvalue);
console.log(this.model);
  // if(localvalue==undefined||localvalue==null){
  //   this.beerrate = localvalue;
    console.log("1"+this.localvalue);
  // }else{
  // this.beerrate = this.localvalue;
  // console.log("2"+this.beerrate);
  // }

  this.shops.beerprice(this.model,this.localvalue)
  .subscribe(
    data=>{
      console.log(data.result);
      (data.result=="okey")?this.getbeerprice():console.log("value is wrong")
    }
    );
}
public barChartOptions:any = {
  scaleShowVerticalLines: false,
  responsive: true,
  options: { legend: { display: false }}
};
public barChartLabels:string[] = ['2017-1', '2017-2', '2017-3', '2017-4', '2017-5', '2017-6', '2017-7',"2017-8","2017-9","2017-10","2017-11","2017-12"];
public barChartType:string = 'bar';
public barChartLegend:boolean = false;
public chartColors: any[] = [
  { 
    backgroundColor:["#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4"] 
  }];
public barChartData:any[] = [
  {data: [0, 0, 0, 0, 0, 0, 0,0,0,0,0,0],
   label:"",
  },
 
  
  // {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'}
];

// // events
public chartClicked(e:any):void {
  console.log(e);
}

public chartHovered(e:any):void {
  console.log(e);
}

public randomize():void {
  // Only Change 3 values
  let data = [
    Math.round(Math.random() * 100),
    59,
    80,
    (Math.random() * 100),
    56,
    (Math.random() * 100),
    40];
  let clone = JSON.parse(JSON.stringify(this.barChartData));
  clone[0].data = data;
  this.barChartData = clone;
 
}
// getImg(){
//   this.shops.getImg(this.shop_id)
//   .subscribe(
//     data=>{
//       console.log(data);
//       this.media1 = data.result;
     
//       console.log(this.media1);
//     }
//   )
// }

upload(){
  this.active=true;

  // console.log(this.fileEvent);
  this.shops.media_upload(this.fileEvent.target.files,this.localvalue)
 .subscribe(
   
    data=>{
      console.log("success"+data)
     
       this.active = false;
      this.getImg1();
       this.active2=true;
       setTimeout(()=>{ this.active2 = false; },2000);
    }
  
 );
}

upload2(){
  this.active=true;

  // console.log(this.fileEvent);
  this.shops.logo(this.fileEvent.target.files,this.localvalue)
 .subscribe(
   
    data=>{
      console.log("success"+data)
     
       this.active = false;
      
       this.active2=true;
       setTimeout(()=>{ this.active2 = false; },2000);
    }
  
 );
}
uploadFile(event){
  // alert(event)
  // console.log(event);
 
      this.fileEvent = event;
      
      this.fileName = event.target.files[0].name;
     
      this.errorFileType = false;
      (this.fileName != null)?this.upload():console.log('empty');

}
uploadFile2(event){
  // alert(event)
  // console.log(event);
 
      this.fileEvent = event;
      
      this.fileName = event.target.files[0].name;
     
      this.errorFileType = false;
      (this.fileName != null)?this.upload2():console.log('empty');

}
}
