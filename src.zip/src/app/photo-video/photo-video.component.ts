import { Component, OnInit ,ViewChild} from '@angular/core';
import { shops } from '../service/shops';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {FormArray,FormControl, FormGroup,FormBuilder,FormsModule,ReactiveFormsModule,NG_VALIDATORS,Validator,Validators,AbstractControl,ValidatorFn, NgForm } from '@angular/forms';
@Component({
  selector: 'app-photo-video',
  templateUrl: './photo-video.component.html',
  styleUrls: ['./photo-video.component.css']
})
export class PhotoVideoComponent implements OnInit {
  upp: boolean;

  
  active2: boolean;
  active: boolean;
  local2: any;
  media1=[];
  media: any[];
  type: number;
  shop_id: any;
  @ViewChild('myInput')
  myInputVariable: any;
 
  public fileEvent=null;
  private fileName;
  checked :Array<any> = [] ;
  private errorFileType:boolean = false;
  myForm: FormGroup;
  constructor(private activatedRoute: ActivatedRoute,private shops:shops,private routes:Router,private fb: FormBuilder) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      id: this.fb.array([])
    });
    this.activatedRoute.params.subscribe((params: Params) => {
      this.shop_id = params['shop_id'];
      if(this.shop_id==undefined){this.upp=true;}else{this.upp=false}
     this.getImg();
      this.active=false;
      this.active2=false;
   });
  }
  del(){
    console.log(this.myForm.value.id)
    console.log(this.checked);
       this.shops.delImg(this.myForm.value.id)
       .subscribe(
         data=>{
           console.log("del"+data);
           this.getImg2(this.local2);
         }
       )
    // console.log(this.checked)
    // // console.log("checked"+this.checked[0].id)
    // this.shops.delImg(this.checked)
    // .subscribe(
    //   data=>{
    //     console.log("del"+data);
    //     this.getImg2(this.local2);
    //   }
    // )
  }
  getImg2(value){
    this.shops.getImg(value)
    .subscribe(
      data=>{
        console.log(data);
        this.media1 = data.result;
       
        console.log(this.media1);
      }
    )
  }
  logout(){
    //  alert("hi")
    this.routes.navigate(['/login']);
    sessionStorage.clear();
    localStorage.clear();
    localStorage.setItem('verify',JSON.stringify({verify_id:0}));
    localStorage.setItem('currentvalue', JSON.stringify({state:"NC",city:"Releigh"}));

  }
  updateChecked(option:string,id:string, isChecked: boolean) {
    console.log(id);
    this.local2 = id;
    // this.checked.push({
    //   id:option
    // })
    const emailFormArray = <FormArray>this.myForm.controls.id;
    
          if(isChecked) {
            emailFormArray.push(new FormControl(option));
          } else {
            let index = emailFormArray.controls.findIndex(x => x.value == option)
            emailFormArray.removeAt(index);
          }
    
  }
  
  getImg(){
    this.shops.getImg(this.shop_id)
    .subscribe(
      data=>{
        console.log(data);
        this.media1 = data.result;
       
        console.log(this.media1);
      }
    )
  }
  back(){
    this.routes.navigate(['/MerchantDetails/stores#store-details'])
  }
  upload(){
   this.active=true;
  
    // console.log(this.fileEvent);
    this.shops.media_upload(this.fileEvent.target.files,this.shop_id)
   .subscribe(
     
      data=>{
        console.log("success"+data)
       
        this.active = false;
        this.getImg();
        this.active2=true;
        setTimeout(()=>{ this.active2 = false; },2000);
      }
    
   );
  }
  uploadFile(event){
    // alert(event)
    // console.log(event);
   
        this.fileEvent = event;
        
        this.fileName = event.target.files[0].name;
       
        this.errorFileType = false;
        (this.fileName != null)?this.upload():console.log('empty');

  }
  reset() {
    
    this.myInputVariable.nativeElement.value = "";
    
}
}
