import { Component, forwardRef, Attribute,OnChanges, SimpleChanges,Input, OnInit } from '@angular/core';
import {FormControl, FormGroupDirective, FormsModule,ReactiveFormsModule,NG_VALIDATORS,Validator,Validators,AbstractControl,ValidatorFn, NgForm } from '@angular/forms';
import { signup } from '../service/signup';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
// import {, NgForm, Validators} from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
// import {ErrorStateMatcher} from '@angular/material/core';
// export class MyErrorStateMatcher implements ErrorStateMatcher {
//   isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
//     const isSubmitted = form && form.submitted;
//     return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
//   }
// }
@Component({
  selector: 'app-merchant-signup',
  templateUrl: './merchant-signup.component.html',
  styleUrls: ['./merchant-signup.component.css']
})
export class MerchantSignupComponent implements OnInit {
  id: any;
  address: any;
  city: any;
  state: any;
  country: any;
  samp :any;
  zipcode: any;
  cmp_name: any;
  login_msg: boolean;
  msg: any;
  mask: any[] = ['+', '1', ' ', '(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  model:any={};
  
  // public name:string;
  // public email: string;
  // public mobile: number;
  // public gender: string;
  // public password: any;
  // public confirmPassword: any
   //pattern=/06([0-9]{8})/;
  constructor(private signup: signup,private router:Router,private activatedRoute: ActivatedRoute) { }
  // 
  ngOnInit() {

    this.activatedRoute.params.subscribe((params: Params) => {
      this.id = params['id']
      });
      if(this.id==1 || this.id==null){
        this.cmp_name = "";
        this.address = "";
        this.city = "";
        this.state = "";
        this.country = "";
        this.zipcode = "";
        this.samp = "";
      }else{
    var deta = JSON.parse(localStorage.getItem('details'));
    this.cmp_name = deta.cmp_name;
    this.address = deta.address+",";
    this.city = deta.city+",";
    this.state = deta.state;
    this.country = deta.country.toUpperCase();
    this.zipcode = deta.zipcode;
    this.samp = "Create a free merchant account for "+"  ";
      }
  }
  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);

  // matcher = new MyErrorStateMatcher();
  onSignup(){
    localStorage.setItem('currentUser', JSON.stringify({ mob: this.model.mobile}));
        this.signup.signup(this.model)

       // console.log(this.model);
       .subscribe(
        data => { this.msg = data.msg; console.log(data)},
        err => console.log(err),
        () => {if(this.msg==0)
        {console.log("Email already exists");
        this.login_msg=true;
        setTimeout(()=>{ this.login_msg = false; },2000);}
        else{console.log("okey");this.router.navigate( ['/login']);}});
  }
}
