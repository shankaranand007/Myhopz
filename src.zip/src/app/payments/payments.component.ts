import { Component, OnInit } from '@angular/core';
import { Http, Headers, Response ,HttpModule} from '@angular/http';
import {Router, ActivatedRoute, Params} from '@angular/router';
@Component({
  selector: 'app-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.css']
})
export class PaymentsComponent implements OnInit {
  payment_info=[];
  

  constructor(private http:Http,private routes:Router) { }

  ngOnInit() {
    this.getData();
  }
  getData(){
    const value = localStorage.getItem('admin');
    const formData: FormData = new FormData();
    formData.append("user_id",value);
    this.http.post('https://myhopz.com/myhopz_dev/index.php/Payment/getpayinfo',formData)
    .map((res: Response) => res.json())
    .subscribe(
      data=>{
        console.log(data.result)
        this.payment_info = data.result;
      }
    )
  }
  logout(){
    //  alert("hi")
    this.routes.navigate(['/login']);
    sessionStorage.clear();
    localStorage.clear();
    localStorage.setItem('verify',JSON.stringify({verify_id:0}));
    localStorage.setItem('currentvalue', JSON.stringify({state:"NC",city:"Releigh"}));

  }
  call(data){
  
   var splitted = data.split(" ",1);
   return splitted; 
  }
pay2(data){

  if(data=="direct"){
    var data1 = "Direct Deposit"
    return data1;
  }else if(data=="check"){
    var data1="Check"
    return data1;
  }else{
    var data1="";
    return data1;
  }
}
}
