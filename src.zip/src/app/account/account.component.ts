import { Component, OnInit } from '@angular/core';
import {  ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  to: any;
  active2: boolean;
  active1: boolean;

  constructor(private router:Router,) { }
  
  ngOnInit() {
    this.active1 = true;
    this.to='0';
  }
  AI(){
    
   this.to='0';
  }
  store(){
    this.active1 = false;
    this.active2 =true;
    this.router.navigate(['/MerchantDetails/stores']);
  }
  pay(){
    this.to='0';
  }
  
  open1(){
    
    this.to='1';  
  }
  user(){
    this.to='0';
  }
  report(){
    this.to='0';
  }
  logout(){
    sessionStorage.clear();
    localStorage.clear();
    localStorage.setItem('verify',JSON.stringify({verify_id:0}));
    this.router.navigate(['/login']);
  }
}
