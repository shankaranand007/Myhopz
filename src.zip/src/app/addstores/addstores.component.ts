import { Component, OnInit } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';
import { shops } from '../service/shops';
@Component({
  selector: 'app-addstores',
  templateUrl: './addstores.component.html',
  styleUrls: ['./addstores.component.css']
})
export class AddstoresComponent implements OnInit {
  spinner: boolean;
  call: boolean;
 
  pos: any;
  public positions=[];
  model:any={}; 
  constructor(private http: Http,
    private router: Router,public shops:shops,) { }

  ngOnInit() {

  }
   getData(){
    this.pos=[];
    //alert(JSON.stringify(this.model));
    this.spinner=true;
    let name = this.model.name;
    let place = this.model.place;
    if(name==""&&place==""){
      this.call=true;
      this.spinner=false;
    }else{
     
      const formData:FormData = new FormData();
      formData.append('shop_name',name);
      formData.append('city',place);
     this.http.post('https://myhopz.com/myhopz_dev/index.php/Store_search',formData)
            .map((res: Response) => res.json())
            
            .subscribe(
               data => { 
                 
                if(data.error_code=='01'){
                  this.pos=data.result;
                  this.call=true;
                  this.spinner=false;
                }else{
                  this.call=false;
                this.pos=data.result;
                console.log(this.pos);
                this.spinner=false;
              //   for (let i = 0 ; i < this.pos.length; i++) {
              //     let marker = this.pos[i];
              //       let randomLat = marker.latitude;
              //        let randomLng = marker.longitude;
              //        let randomname = marker.shop_name;
              //        let address = marker.address;
              //        let id = marker.shop_id;
              //        let status = marker.shopstatus;
              //        let claim = marker.climcount;
              //        let city = marker.city;
              //        let state = marker.state;
              //        let img  = marker.background_image;
              //        let country = marker.countryname;
              //        let zipcode = marker.zipcode;
              //        let storetime = marker.storetime;
              //        let phone = marker.phone;
              //        let label = marker.shoplabel;
              //        let website = marker.website;
                     
              //        this.positions.push({lattt: randomLat, lnggg: randomLng,name_3: randomname,shop_id:id,status:status,claim:claim,city:city,state:state,img:img,
              //         address:address,country:country,
              //         zipcode:zipcode,storetime:storetime,
              //         phone:phone,
              //         label:label,
              //         website:website
              //       });
                    
                                    
              //  }
              }
              },
              
               err => console.log(err),
               () => {if(this.pos=="Empty")
               {console.log("empty")}
               else{console.log("okey")}}
              );
               
               //this.getSomething(this.pos);
  }
}
  logout(){
    //  alert("hi")
    this.router.navigate(['/login']);
    sessionStorage.clear();
    localStorage.clear();
    localStorage.setItem('verify',JSON.stringify({verify_id:0}));
    localStorage.setItem('currentvalue', JSON.stringify({state:"NC",city:"Releigh"}));

  }
  claim(data)
    {
      console.log(data);
      localStorage.setItem('details', JSON.stringify({cmp_name:data.shop_name,address:data.address,
        city:data.city,state:data.state,country:data.country_name,
        zipcode:data.zipcode,storetime:data.storetime,
        img:data.background_image,phone:data.phone,
        label:data.shop_label,website:data.website,shop_id:data.shop_id,lattt:data.latitude,lnggg:data.longitude,
        
      }));
      this.router.navigate(["/VerifybreweryComponent"]);
      // this.shops.claim(data)
      // .subscribe(
      //   data => {console.log(data)},
      // );
    }
}
