import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-verifybrewery',
  templateUrl: './verifybrewery.component.html',
  styleUrls: ['./verifybrewery.component.css']
})
export class VerifybreweryComponent implements OnInit {
  img: any;
  zipcode: any;
  country: any;
  state: any;
  city: any;
  address: any;
  cmp_name: any;
public mobile_number:any;
  constructor(private router:Router) { }

  ngOnInit() {
     var details = JSON.parse(localStorage.getItem('details'));
    //console.log(details);
   
    (details != null&&details.cmp_name != "")?
    this.getData()
    : 
      this.router.navigate( ['/MerchantDetails']);
     }
  getData(){
      var details = JSON.parse(localStorage.getItem('details'));
    this.cmp_name = details.cmp_name;
    this.address = details.address;
    this.city= details.city;
    this.state=details.state;
    this.country = details.country;
    this.zipcode = details.zipcode;
    this.img = details.img;
    this.mobile_number = details.phone;
  }
  verify2(){
    this.router.navigate( ['/Verifybrewary2Component']);
    localStorage.setItem('v11','s');
  }
  logout(){
    this.router.navigate(['/login']);
    sessionStorage.clear();
    localStorage.clear();
    localStorage.setItem('verify',JSON.stringify({verify_id:0}));
  }
}
