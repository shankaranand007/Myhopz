import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { Http, Headers, Response ,HttpModule} from '@angular/http';
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import { current } from '../service/current';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  inactive: boolean;
  active: boolean;
  public positions=[];
  pos: any;
  public state = "NC";
  
  public city="Releigh";
  name:any;
  model:any={};
  public namee:string;
  public login_msg;
  constructor(private activatedRoute: ActivatedRoute ,private router: Router,private http:Http, private _sanitizer: DomSanitizer,private current:current) {}

  location = {};
  
  ngOnInit() {
    localStorage.setItem('details',JSON.stringify({'cmp_name':''}));
     //this.getLocation();
     this.current.local();
       this.getData();
    // subscribe to router event
    const value = JSON.parse(localStorage.getItem('verify'));
    
    var vl = value;
    
    //  console.log("log"+localStorage.getItem('verify'));
    //  console.log("log2"+vl);
    if(vl !=null){
      if(vl.verify_id==0){
       console.log("call1")
      this.call1()
      }else{
      
      this.call2()
    }
  }else{
    this.active=true;
    localStorage.setItem('verify',JSON.stringify({verify_id:0}));
  }
    
    // (vl == null)?
    // localStorage.setItem('verify',JSON.stringify({verify_id:0})):console.log("VALUE IS THERE");
    localStorage.setItem('currentvalue', JSON.stringify({state:"NC",city:"Releigh"}));
        
   }
   call1(){this.active=true;this.inactive=false}
   call2(){this.active=false;this.inactive=true}
   logout()
   {localStorage.clear();this.call1(); 
    localStorage.setItem('verify',JSON.stringify({verify_id:0}));
    localStorage.setItem('currentvalue', JSON.stringify({state:this.state,city:this.city}));
  }
  getData(){

      const formData:FormData = new FormData();
        
      //header.append('Access-Control-Allow-Origin', '*');
      //console.log(formData);
     this.http.post('https://myhopz.com/myhopz_dev/index.php/Shop',formData)
            .map((res: Response) => res.json())
            
            .subscribe(
               data => { this.pos=data.result;
                for (let i = 0 ; i < this.pos.length; i++) {
                  let marker = this.pos[i];
                     let city = marker.city;
                     let state = marker.state;
                     
                     let country = marker.countryname;
                     let zipcode = marker.zip_code;
                    
                     
                     this.positions.push({city:city,state:state,
                       zipcode:zipcode
                 
                    });
                    
                                    
               }
              
              },
              
              //  err => console.log(err),
              //  () => {if(this.pos=="Empty")
              //  {console.log("empty")}
              //  else{console.log("okey")}}
              );
               
               //this.getSomething(this.pos);
  }
  autocompleListFormatter = (name:any) => {
    //console.log(name)
    let html =  `<p >${name.city} ,${name.state},${name.zipcode} </p>`;
    return this._sanitizer.bypassSecurityTrustHtml(html);
  }
  click(){
    //alert(this.model.name);
    if(this.model.name == undefined || this.model.name == ''){
      this.login_msg=true;
      setTimeout(()=>{ this.login_msg = false; },700);
    } else {
      
      var arr = Object.keys(this.model);
      let ln =arr[0];
      if(ln == '0'){
       
        localStorage.setItem('map',JSON.stringify({map:this.model}));
      }else{
     
     localStorage.setItem('map',JSON.stringify({map:this.model}));
      }
      
    this.router.navigate(['/map']);
    }
    
     
  }
  //getLocation(){
    //this.current.local()
//     var lati2;
//     var logi2;
//     if(navigator.geolocation){
//       navigator.geolocation.getCurrentPosition(position => {
//         this.location = position.coords;
//        lati2= position.coords.latitude;
//        logi2= position.coords.longitude;

//       var lat =lati2;
//       var lng = logi2 ;
//         const header = new Headers();
//         // header.append( 'Content-Type', 'application/json');
//          header.append('Access-Control-Allow-Origin', '*');
//          header.append('Access-Control-Allow-Origin', 'http://localhost:4200');
//          header.append('Access-Control-Request-Method', 'POST');
//          header.append('Access-Control-Allow-Headers:application/json',' Content-Type');

//         this.http.get('https://maps.googleapis.com/maps/api/geocode/json?latlng='+lat+','+lng)
//         .map((res: Response) => res.json())
//         .subscribe(
//           data => { console.log(data.results[0]);
            
//                         var len = parseInt(data.results[0]['address_components'].length);
                        
//                          var len2 = len-3;
//                          var len3 = len-4;
//                         var country=data.results[0]['address_components'][7].short_name;
//                          this.state=data.results[0]['address_components'][len2].short_name;
//                          this.city=data.results[0]['address_components'][len3].long_name;
//                          localStorage.setItem('currentvalue', JSON.stringify({state:this.state,city:this.city}));
                      
//           });
//         });
//         }
//     console.log("current"+this.state,this.city);
       
 //}
}
