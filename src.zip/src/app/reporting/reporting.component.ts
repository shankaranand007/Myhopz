import { Component, OnInit } from '@angular/core';
import { shops } from '../service/shops';
import {Router, ActivatedRoute, Params} from '@angular/router';
@Component({
  selector: 'app-reporting',
  templateUrl: './reporting.component.html',
  styleUrls: ['./reporting.component.css']
})
export class ReportingComponent implements OnInit {
  media1: any;
  claimed2: any[];
  localvalue: any;
  pos: any;
  arrow: boolean;
  public claimed=[];
  data: Object;
  selected = 'Last Day';
  constructor(private shops:shops,private routes:Router) { }

  ngOnInit() {
    this.getData();
    this. emptyclaim();
  }
  emptyclaim(){
   
   this.claimed = [
        {
         
          "name_3": "Eg: BigBoss Brewary",
          "website": "Eg: www.BigBoss.com",
          "phone":"Eg: (979) 0054083",
          "address":"Eg: 14,ponniyer street",
          "country":"USA",
          "zipcode":"12124",
          "img" :"assets/images/samplee.jpg",
          "state":"NC",
          "city":"Charlotte",
        },
    ]
  }
  
  getData(){
    this.shops.claimed()
    .subscribe(
      data=>{console.log(data.result)
        if(data.result.length==0){
          this.emptyclaim();
          this.arrow = false;
        }else{
         
          this.arrow = true;
        this.pos=data.result;
        for (let i = 0 ; i < this.pos.length; i++) {
          let value = this.pos[i];
           
           
          let address = value.address;
          let city = value.city;
          let countryname = value.countryname;
          let img = value.image;
          let lat = value.lat;
          let long = value.longg;
          let phone = value.phone;
          let shop_id = value.shop_id;
          let state = value.state;
          let storetime = value.storetime;
          let user_id = value.merchant_id;
          let web = value.website;
          let zip = value.zip;
          let shop_name = value.shop_name;
           
           this.claimed.push({lattt: lat, lnggg: long,name_3: shop_name,shop_id:shop_id,status:status,
            city:city,state:state,img:img,
            address:address,country:countryname,select:"inactive",
            zipcode:zip,storetime:storetime,
            phone:phone,
            website:web
          });
            // this.localvalue=this.claimed[0];
            
            
                            
       }
      }
      //  (this.claimed.length==0)?this.emptyclaim():console.log("not empty");
       this.localvalue =this.claimed[0].shop_id;
      //  alert(this.localvalue);
       this.claimed2 = this.claimed
       this.getImg1();
      //  console.log(this.localvalue);
      
      
      
      }
    );
  }
  nxt(data){
    //alert(data);
    if(this.claimed2.length == data+1){
    //  alert("hi")
      this.localvalue = this.claimed2[data].shop_id;
    
      
    } else{
     
      this.localvalue = this.claimed2[data+1].shop_id;
      
      
    }
    // this.localvalue = this.claimed2[data+1].shop_id;
    // alert(this.localvalue);
    console.log(this.claimed2.length);
    
   
    this.getImg(this.localvalue);
    // alert(data);
    // this.randomize();
  }
  getImg1(){
    this.shops.getImg(this.localvalue)
    .subscribe(
      data=>{
        console.log(data);
        this.media1 = data.result;
       
        console.log(this.media1);
      }
    )
  }
  getImg(value){
    this.shops.getImg(value)
    .subscribe(
      data=>{
        console.log(data);
        this.media1 = data.result;
       
        console.log(this.media1);
      }
    )
  }
  pre(data){
    if(data==0){
      this.localvalue=this.claimed[this.claimed2.length-1].shop_id;
      // console.log(this.claimed[this.claimed.length-1]);
      
    } else{
      this.localvalue=this.claimed2[data-1].shop_id;
      // console.log(this.claimed[data-1]);
      
    }
     alert(this.localvalue);
    
    this.getImg(this.localvalue);
    
  }
  logout(){
    //  alert("hi")
    this.routes.navigate(['/login']);
    sessionStorage.clear();
    localStorage.clear();
    localStorage.setItem('verify',JSON.stringify({verify_id:0}));
    localStorage.setItem('currentvalue', JSON.stringify({state:"NC",city:"Releigh"}));

  }
  public barChartOptions:any = {
    scaleShowVerticalLines: false,
    responsive: true,
    options: { legend: { display: false }}
  };
  public barChartLabels:string[] = ['2017-1', '2017-2', '2017-3', '2017-4', '2017-5', '2017-6', '2017-7',"2017-8","2017-9","2017-10","2017-11","2017-12"];
  public barChartType:string = 'bar';
  public barChartLegend:boolean = false;
  public chartColors: any[] = [
    { 
      backgroundColor:["#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4","#4682b4"] 
    }];
    public chartColorss: any[] = [
      { 
        backgroundColor:["#39b54a","#39b54a","#39b54a","#39b54a","#39b54a","#39b54a","#39b54a","#39b54a","#39b54a","#39b54a","#39b54a","#39b54a"] 
      }];
  
  public barChartData:any[] = [
    {data: [0, 0, 0, 0, 0, 0, 0,0,0,0,0,0],
     label:"",
    },
   
    
    // {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'}
  ];
 
  // // events
  public chartClicked(e:any):void {
    console.log(e);
  }
 
  public chartHovered(e:any):void {
    console.log(e);
  }
 
  public randomize():void {
    // Only Change 3 values
    let data = [
      Math.round(Math.random() * 100),
      59,
      80,
      (Math.random() * 100),
      56,
      (Math.random() * 100),
      40];
    let clone = JSON.parse(JSON.stringify(this.barChartData));
    clone[0].data = data;
    this.barChartData = clone;
    /**
     * (My guess), for Angular to recognize the change in the dataset
     * it has to change the dataset variable directly,
     * so one way around it, is to clone the data, change it and then
     * assign it;
     */
  }

}
