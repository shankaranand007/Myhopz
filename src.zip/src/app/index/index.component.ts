import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import 'rxjs/add/operator/toPromise';
import { Http, Headers, Response ,HttpModule} from '@angular/http';
import {ModalModule} from "ng2-modal";
import { Observable } from 'rxjs/Observable';
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import { current } from '../service/current';

import 'rxjs/add/operator/map';
@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
  rating: any;
  formated_address: any;
  logo: any;
  log: any;
  lat: any;
  inactive: boolean;
  active: boolean;
  vl: any;
 

  current_state: any;
  current_city: any;
  bmap: any;
  cityyy: any;
  statt: any;
  length: any;
  map: any;
  website: any;
  label: any;
  logi2: any;
  lati2: any;
  storetime: any;
  zipcode: any;
  country: any;
 
  msg: any;
  imgSrc="assets/images/ss.png";
  userId = '';
  public positions=[];
  randomLat = '';
  randomLng = '';
  randomname= '';
  public lati ="35.579864";
  public longi  = "-79.248706";
  public zoom = "13";
  pos:any;
  public test={};
  public id:any;
  public sname:any;
  public city:any;
  public state:any;
  public src :any;
  public address:any;
  public cityy="charlotte"
  public count = "usa"
  public stat  = ""
  public phone;
  search:any;
  
    

       constructor(private current:current,private activatedRoute: ActivatedRoute, private router: Router,private http:Http, private _sanitizer: DomSanitizer) {}

      ngOnInit() {
        this.current.local();
        this.getData();
        const valuee = JSON.parse(localStorage.getItem('verify'));
        this.vl = valuee.verify_id;
        this.getHead();
        var currentvalue = JSON.parse(localStorage.getItem('currentvalue'));
        //this.current_state = 
        console.log("hi"+currentvalue.state);
        (currentvalue.state==null)? this.current_state = "nc" : this.current_state = currentvalue.state;
         //this.current_city = currentvalue.city;
         (currentvalue.city==null)? this.current_city = "charlotte": this.current_city = currentvalue.city;
        var mapvalue = JSON.parse(localStorage.getItem('map'));
        if(mapvalue==null){
         
          this.cityy ="charlotte";
          this.stat = "NC";
        }else{
        this.search=mapvalue.map.name;
        var arr = Object.keys(this.search);
        //alert(this.search);
        let ln =arr[0];
        if(ln == '0'){
          this.zoom = "9";
          this.cityy=this.search;
          this.stat = "nc";
        }
        else{
        var comma = JSON.stringify(mapvalue.map.name).indexOf(",");
        if(comma==-1) {
          console.log(mapvalue.map.name);
          this.map = mapvalue.map.name.city;
           var value=this.map;
           this.cityy=value;
           this.zoom = "9";
        }
        else {
           console.log(mapvalue.map.name);
          this.zoom = "9";
          this.cityy = mapvalue.map.name.city;
          this.stat = mapvalue.map.name.state;
          //this.map = mapvalue.map.name+',';
              //  console.log(this.map);
            
                            //  var  value=this.map.split(",");
                             
                            //  var length=value.length;
                            //  this.cityyy=value[length-3];
                             
                            //  this.statt=value[length-2];
                            //  console.log(this.cityyy+" "+this.statt)
                            // //alert(this.cityyy+" "+this.statt);
                            // this.city = this.cityyy;
                            // this.stat = this.statt;
                            
         }
        }
        }
           // this.activatedRoute.params.subscribe((params: Params) => {
          // this.map = params['map']
          // });
        
      }
      getHead(){
        if(this.vl==0)
        {
          this.active=true;
          this.inactive=false;
        }else{
          this.active = false;
          this.inactive = true;
        }
      }
      logout(){
        this.router.navigate(['/login']);
        sessionStorage.clear();
        localStorage.clear();
        localStorage.setItem('verify',JSON.stringify({verify_id:0}));
        localStorage.setItem('currentvalue', JSON.stringify({state:"NC",city:"Releigh"}));
    
      }
      autocompleListFormatter = (search: any) => {
        let html =  `<p >${search.city} ,${search.state},${search.zipcode} </p>`;
        return this._sanitizer.bypassSecurityTrustHtml(html);
      }
      // getSearchText(text)
      // {
        
      //   var location = this.state.markerOriginal
    
      //     var filterValue = location.filter(function(searchWord){
      //       return searchWord['zipcode'].toLowerCase().indexOf(text) != -1 || searchWord['city'].toLowerCase().indexOf(text) != -1 || searchWord['state'].toLowerCase().indexOf(text) != -1
    
      //     });
      //   }
    //   getSomething(pos){
    //     for (let i = 0 ; i < 10; i++) {
    //       let marker = pos[i];
    //         let randomLat = marker.latitude;
    //          let randomLng = marker.longitude;
    //          let randomname = marker.shopname;
    //          let id = marker.id;
    //          let status = marker.status;
    //          let claim = marker.climcount;
    //          let city = marker.city;
    //          let state = marker.state;
    //          let img  = marker.backgroundimage
    //         this.positions.push({lattt: randomLat, lnggg: randomLng,name: randomname,id:id,status:status,claim:claim,city:city,state:state,img:img});
    //         //console.log(positions);
    //       //this.positions.push([randomLat, randomLng]);
         
       
    //   }
    //     //this.positions.push();
    // }
    details(data){
      // alert(data.sname);
      this.id = data.id;
      this.sname = data.name_3;
      this.city = data.city;
      this.state =data.state;
      this.src = data.img;
      this.logo = data.logo;
      this.address = data.address
      this.country =data.country; 
      this.zipcode = data.zipcode;
      this.storetime = data.storetime; 
      this.phone = data.phone;
      this.label = data.label;
      this.website = data.website;
      this.lat = data.lattt;
      this.log = data.lnggg;
      // ----
      var fa = data.formated_address;
      var aft_fa = fa.substring(0, fa.lastIndexOf(","));
      this.formated_address = aft_fa;
      // ----
      this.rating = data.rating;
    }
    
getData(){
   
        const formData:FormData = new FormData();
     
       this.http.post('https://myhopz.com/myhopz_dev/index.php/Shop',formData)
              .map((res: Response) => res.json())
              
              .subscribe(
                 data => { this.pos=data.result;
                  for (let i = 0 ; i < this.pos.length; i++) {
                    let marker = this.pos[i];
                      let randomLat = marker.latitude;
                       let randomLng = marker.longitude;
                       let randomname = marker.shop_name;
                       let address = marker.address;
                       let logo = marker.shop_label;
                       let id = marker.shop_id;
                       let status = marker.shop_status;
                       let claim = marker.climcount;
                       let city = marker.city;
                       let state = marker.state;
                       let img  = marker.background_image;
                       let country = marker.country_name;
                       let zipcode = marker.zip_code;
                       let storetime = marker.store_time;
                       let phone = marker.phone;
                       let label = marker.shoplabel;
                       let website = marker.website;
                       let rating = marker.rating;
                       let formated_address = marker.formated_address;
                       
                       this.positions.push({lattt: randomLat, lnggg: randomLng,name_3: randomname,id:id,status:status,claim:claim,city:city,state:state,img:img,
                        address:address,country:country,select:"inactive",
                        zipcode:zipcode,storetime:storetime,rating:rating,
                        phone:phone,formated_address:formated_address,
                        label:label,logo:logo,
                        website:website
                      });
                      
                                      
                 }
                
                },
                
                //  err => console.log(err),
                //  () => {if(this.pos=="Empty")
                //  {console.log("empty")}
                //  else{console.log("okey")}}
                );

    }
   

    b_Log(){
      localStorage.setItem('details', JSON.stringify({cmp_name:this.sname,address:this.address,
        city:this.city,state:this.state,country:this.country,
        zipcode:this.zipcode,storetime:this.storetime,
        img:this.src,phone:this.phone,
        label:this.label,website:this.website,shop_id:this.id,lattt:this.lat,lnggg:this.log,
      }));
      this.router.navigate(["/login"]);
      
    }
    activeimage(data){
      
      for(let i=0;i<this.positions.length;i++){
        if(this.positions[i]==this.positions[data]){
          this.positions[data].select='active';
        } else{
          this.positions[i].select='inactive';
        }
      }
     
    }

    fileChangeEvent (text){
    
    console.log('text'+text);
    var comma = JSON.stringify(text).indexOf(",");
    if(comma==-1) {
      this.zoom = "9";
      this.map = text;
      var value=this.map;
      this.cityy=value;
    }
    else {
      this.zoom = "9";
      this.map = text+',';
          //  console.log(this.map);
                var  value=this.map.split(",");
                var length=value.length;
                this.cityyy=value[length-3];
                this.statt=value[length-2];
                this.cityy = this.cityyy;
                this.stat = this.statt;
     }
     }
      cclick(){
        this.router.navigate( ['/BrewerydetailsComponent',{cmp_name:this.sname,address:this.address,
          city:this.city,state:this.state,country:this.country,formated_address:this.formated_address,
          zipcode:this.zipcode,storetime:this.storetime,logo:this.logo,
          img:this.src,phone:this.phone,rating:this.rating,
          label:this.label,website:this.website,shop_id:this.id,lattt:this.lat,lnggg:this.log,
        } ]);
        //console.log(this.positions);
        localStorage.setItem('details', JSON.stringify({cmp_name:this.sname,address:this.address,
          city:this.city,state:this.state,country:this.country,
          zipcode:this.zipcode,storetime:this.storetime,logo:this.logo,
          img:this.src,phone:this.phone,formated_address:this.formated_address,rating:this.rating,
          label:this.label,website:this.website,shop_id:this.id,lattt:this.lat,lnggg:this.log,
        }));
      }
      bclick(){
        alert("button click");
      }
      
   }
   